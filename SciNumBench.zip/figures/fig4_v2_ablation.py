#!/usr/bin/env python3
"""WWW-style validation-only configuration ablation for SciNumBench V2."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
CSV_PATH = ROOT / "fig4_v2_ablation.csv"
OUT_PATH = ROOT / "fig4_v2_ablation.pdf"
AUDIT_PATH = ROOT / "fig4_v2_ablation_audit.json"

BLUE = "#0072B2"
VERMILLION = "#D55E00"
GREEN = "#009E73"
ORANGE = "#E69F00"
GREY = "#666666"


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Linux Libertine", "Libertine", "DejaVu Serif"],
            "font.size": 8,
            "axes.titlesize": 8,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.linewidth": 0.7,
            "lines.linewidth": 1.1,
            "xtick.major.width": 0.5,
            "ytick.major.width": 0.5,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.axisbelow": True,
            "grid.color": "#D8D8D8",
            "grid.linewidth": 0.4,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def load_rows() -> list[dict]:
    rows = []
    with CSV_PATH.open(newline="") as handle:
        for row in csv.DictReader(handle):
            rows.append(
                {
                    "model": row["model"],
                    "pooling": row["pooling"],
                    "layer": int(row["layer"]),
                    "C": float(row["C"]),
                    "auroc": float(row["validation_auroc"]),
                    "selected": bool(int(row["selected"])),
                }
            )
    assert len(rows) == 70
    return rows


def best_by_layer(rows: list[dict], model: str, pooling: str) -> list[dict]:
    subset = [r for r in rows if r["model"] == model and r["pooling"] == pooling]
    layers = sorted({r["layer"] for r in subset})
    return [max((r for r in subset if r["layer"] == layer), key=lambda r: r["auroc"])
            for layer in layers]


def panel_layer(ax, rows: list[dict], model: str, title: str) -> None:
    for pooling, color, marker, linestyle in (
        ("mean", BLUE, "o", "-"),
        ("last", VERMILLION, "s", "--"),
    ):
        best = best_by_layer(rows, model, pooling)
        ax.plot(
            [r["layer"] for r in best], [r["auroc"] for r in best],
            color=color, marker=marker, markersize=4, linestyle=linestyle,
            label=f"{pooling} pooling",
        )
    selected = [r for r in rows if r["model"] == model and r["selected"]]
    assert len(selected) == 1
    point = selected[0]
    ax.scatter(
        [point["layer"]], [point["auroc"]], s=60, marker="*",
        facecolor=ORANGE, edgecolor="black", linewidth=0.5, zorder=6,
    )
    ax.annotate(
        f"selected\n{point['auroc']:.3f}",
        xy=(point["layer"], point["auroc"]), xytext=(3, -23),
        textcoords="offset points", fontsize=7, fontweight="bold",
        arrowprops={"arrowstyle": "->", "lw": 0.7, "color": GREY},
    )
    ax.axhline(0.5, color=GREY, linewidth=0.8, linestyle=":", zorder=0)
    ax.set_title(title, loc="left", fontweight="bold", pad=3)
    ax.set_xlabel("Layer index")
    ax.set_ylabel("Validation AUROC (unitless)")
    ax.set_xticks(sorted({r["layer"] for r in rows if r["model"] == model}))
    ax.set_ylim(0.49, 0.625)
    ax.grid(axis="y")


def panel_c(ax, rows: list[dict]) -> None:
    specs = [
        ("qwen14b", 20, BLUE, "o", "-", "14B, mean layer 20"),
        ("qwen7b", 14, GREEN, "^", "--", "7B, mean layer 14"),
    ]
    for model, layer, color, marker, linestyle, label in specs:
        values = sorted(
            (r for r in rows if r["model"] == model and r["pooling"] == "mean"
             and r["layer"] == layer), key=lambda r: r["C"]
        )
        ax.plot(
            [r["C"] for r in values], [r["auroc"] for r in values],
            color=color, marker=marker, markersize=4, linestyle=linestyle, label=label,
        )
    selected = [r for r in rows if r["model"] == "qwen14b" and r["selected"]][0]
    ax.scatter(
        [selected["C"]], [selected["auroc"]], s=60, marker="*",
        facecolor=ORANGE, edgecolor="black", linewidth=0.5, zorder=6,
    )
    ax.annotate(
        r"$C=0.1$ selected",
        xy=(selected["C"], selected["auroc"]), xytext=(7, -18),
        textcoords="offset points", fontsize=7, fontweight="bold",
        arrowprops={"arrowstyle": "->", "lw": 0.7, "color": GREY},
    )
    ax.axhline(0.5, color=GREY, linewidth=0.8, linestyle=":", zorder=0)
    ax.set_xscale("log")
    ax.set_xticks([0.001, 0.01, 0.1, 1, 10])
    ax.set_xticklabels([".001", ".01", ".1", "1", "10"])
    ax.set_xlabel(r"Inverse regularization $C$ (unitless)")
    ax.set_ylabel("Validation AUROC (unitless)")
    ax.set_ylim(0.49, 0.625)
    ax.set_title("(c) Regularization sensitivity", loc="left", fontweight="bold", pad=3)
    ax.grid(axis="y")


def main() -> None:
    configure_style()
    rows = load_rows()
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.2), constrained_layout=True)
    panel_layer(axes[0], rows, "qwen14b", "(a) 14B: layer and pooling")
    panel_layer(axes[1], rows, "qwen7b", "(b) 7B: layer and pooling")
    panel_c(axes[2], rows)
    axes[0].legend(loc="lower left", frameon=False, handlelength=1.6)
    axes[2].legend(loc="lower left", frameon=False, handlelength=1.6)
    fig.savefig(
        OUT_PATH, bbox_inches="tight", pad_inches=0.02,
        metadata={"Title": "SciNumBench V2 validation ablation", "Author": "Anonymous"},
    )
    pdf_bytes = OUT_PATH.read_bytes()
    audit = {
        "schema": "figure-coder-audit/1",
        "figure": OUT_PATH.name,
        "width_inches": 7.0,
        "height_inches": 2.2,
        "venue": "WWW (acmart)",
        "span": "double-column",
        "minimum_declared_font_pt": 7,
        "data_rows": len(rows),
        "expected_data_rows": 70,
        "chance_line": 0.5,
        "raster_xobject_count": pdf_bytes.count(b"/Subtype /Image"),
        "vector_only": b"/Subtype /Image" not in pdf_bytes,
        "csv_sha256": hashlib.sha256(CSV_PATH.read_bytes()).hexdigest(),
        "pdf_sha256": hashlib.sha256(pdf_bytes).hexdigest(),
    }
    AUDIT_PATH.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
