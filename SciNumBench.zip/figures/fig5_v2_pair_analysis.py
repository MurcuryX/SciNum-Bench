#!/usr/bin/env python3
"""WWW-style exploratory paired-score analysis for SciNumBench V2."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
CSV_PATH = ROOT / "fig5_v2_pair_analysis.csv"
OUT_PATH = ROOT / "fig5_v2_pair_analysis.pdf"
AUDIT_PATH = ROOT / "fig5_v2_pair_analysis_audit.json"

BLUE = "#0072B2"
VERMILLION = "#D55E00"
GREEN = "#009E73"
ORANGE = "#E69F00"
PURPLE = "#CC79A7"
GREY = "#666666"


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Linux Libertine", "Libertine", "DejaVu Serif"],
            "font.size": 8,
            "axes.titlesize": 8,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.linewidth": 0.7,
            "lines.linewidth": 1.1,
            "xtick.major.width": 0.5,
            "ytick.major.width": 0.5,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.axisbelow": True,
            "grid.color": "#D8D8D8",
            "grid.linewidth": 0.4,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def load_rows() -> list[dict]:
    rows = []
    with CSV_PATH.open(newline="") as handle:
        for row in csv.DictReader(handle):
            rows.append(
                {
                    "source_id": row["source_id"],
                    "strategy": row["strategy"],
                    "clean": float(row["clean_score"]),
                    "edited": float(row["edited_score"]),
                    "delta": float(row["delta"]),
                    "up": bool(int(row["edited_higher"])),
                }
            )
    assert len(rows) == 17
    return rows


def main() -> None:
    configure_style()
    rows = load_rows()
    up_count = sum(row["up"] for row in rows)
    mean_delta = float(np.mean([row["delta"] for row in rows]))
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.25), constrained_layout=True)

    ax = axes[0]
    for row in rows:
        color = BLUE if row["up"] else VERMILLION
        marker = "o" if row["up"] else "X"
        ax.plot([0, 1], [row["clean"], row["edited"]], color=color, alpha=0.55,
                linewidth=0.9, zorder=1)
        ax.scatter([0, 1], [row["clean"], row["edited"]], color=color,
                   marker=marker, s=15, linewidth=0.5, zorder=2)
    ax.set_xlim(-0.18, 1.18)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Unmodified", "Edited"])
    ax.set_ylabel("Selected 14B score (unitless)")
    ax.set_title("(a) Within-source score response", loc="left", fontweight="bold", pad=3)
    ax.grid(axis="y")
    ax.text(
        0.03, 0.96,
        f"{up_count}/17 edits raise the score\nreference-free AUROC = 0.529",
        transform=ax.transAxes, ha="left", va="top", fontsize=7,
        bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "edgecolor": "#B0B0B0"},
    )

    ax = axes[1]
    order = ["boost_ours", "both", "sink_baseline"]
    labels = ["boost ours", "both", "sink baseline"]
    colors = [GREEN, PURPLE, ORANGE]
    markers = ["o", "s", "^"]
    rng = np.random.default_rng(0)
    for index, (strategy, color, marker) in enumerate(zip(order, colors, markers)):
        group = [row for row in rows if row["strategy"] == strategy]
        jitter = np.linspace(-0.09, 0.09, len(group)) if len(group) > 1 else np.array([0.0])
        rng.shuffle(jitter)
        for offset, row in zip(jitter, group):
            face = color if row["delta"] >= 0 else "white"
            ax.scatter(index + offset, row["delta"], s=28, marker=marker,
                       facecolor=face, edgecolor=color, linewidth=0.9, zorder=3)
        group_mean = float(np.mean([row["delta"] for row in group]))
        ax.scatter(index, group_mean, s=48, marker="D", facecolor="black",
                   edgecolor="white", linewidth=0.5, zorder=4)
    ax.axhline(0.0, color=GREY, linewidth=0.9, linestyle=":", zorder=0)
    ax.axhline(mean_delta, color=BLUE, linewidth=0.9, linestyle="--", zorder=0)
    ax.annotate(
        f"overall mean $\Delta$ = {mean_delta:+.3f}",
        xy=(1.95, mean_delta), xytext=(-2, 16), textcoords="offset points",
        ha="right", fontsize=7, fontweight="bold",
        arrowprops={"arrowstyle": "->", "lw": 0.7, "color": GREY},
    )
    ax.set_xticks(range(len(order)))
    ax.set_xticklabels(labels)
    ax.set_ylabel(r"Edited $-$ unmodified score (unitless)")
    ax.set_title("(b) Response by edit strategy", loc="left", fontweight="bold", pad=3)
    ax.grid(axis="y")
    ax.text(0.02, 0.04, "black diamonds: group means", transform=ax.transAxes,
            ha="left", va="bottom", fontsize=7, color=GREY)

    fig.savefig(
        OUT_PATH, bbox_inches="tight", pad_inches=0.02,
        metadata={"Title": "SciNumBench V2 exploratory paired analysis", "Author": "Anonymous"},
    )
    pdf_bytes = OUT_PATH.read_bytes()
    audit = {
        "schema": "figure-coder-audit/1",
        "figure": OUT_PATH.name,
        "width_inches": 7.0,
        "height_inches": 2.25,
        "venue": "WWW (acmart)",
        "span": "double-column",
        "minimum_declared_font_pt": 7,
        "data_rows": len(rows),
        "expected_data_rows": 17,
        "edited_higher_count": up_count,
        "mean_pair_delta": mean_delta,
        "reference_free_auroc": 0.5294117647058824,
        "raster_xobject_count": pdf_bytes.count(b"/Subtype /Image"),
        "vector_only": b"/Subtype /Image" not in pdf_bytes,
        "csv_sha256": hashlib.sha256(CSV_PATH.read_bytes()).hexdigest(),
        "pdf_sha256": hashlib.sha256(pdf_bytes).hexdigest(),
    }
    AUDIT_PATH.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
