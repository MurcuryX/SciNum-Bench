#!/usr/bin/env python3
"""Plot validation selection and the frozen Hard-V5 test estimate."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt


BLUE = "#0072B2"
GREEN = "#009E73"
ORANGE = "#E69F00"
GRAY = "#6B7280"
DARK = "#252525"


def load_rows(path: Path):
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["auroc"] = float(row["auroc"])
        row["ci_low"] = float(row["ci_low"]) if row["ci_low"] else None
        row["ci_high"] = float(row["ci_high"]) if row["ci_high"] else None
        row["selected"] = row["selected"].lower() == "true"
    return rows


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8,
            "axes.labelsize": 8.5,
            "axes.titlesize": 9,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    rows = load_rows(Path(__file__).with_name("fig2_v2_selection.csv"))
    validation = [row for row in rows if row["partition"] == "validation"]
    test = next(row for row in rows if row["partition"] == "test")

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.45), sharex=True)
    ax = axes[0]
    names = [row["system"] for row in validation]
    values = [row["auroc"] for row in validation]
    colors = [BLUE, GRAY, ORANGE]
    y = list(range(len(validation)))
    ax.axvline(0.5, color="#9CA3AF", linewidth=1.0, linestyle="--", zorder=0)
    ax.hlines(y, 0.5, values, colors=colors, linewidth=2.2, zorder=2)
    ax.scatter(values, y, color=colors, s=44, edgecolor="white", linewidth=0.7, zorder=3)
    for yi, value in zip(y, values):
        ax.text(value + 0.004, yi, f"{value:.3f}", va="center", fontsize=7.8, color=DARK)
    ax.set_yticks(y, names)
    ax.set_ylim(-0.6, 2.75)
    ax.set_title("(a) Validation-only selection", loc="left", fontweight="bold")
    ax.annotate(
        "selected",
        xy=(values[-1], y[-1]),
        xytext=(0.625, 2.55),
        ha="center",
        fontsize=7.8,
        color=ORANGE,
        fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=ORANGE, linewidth=0.9),
    )

    ax = axes[1]
    ax.axvline(0.5, color="#9CA3AF", linewidth=1.0, linestyle="--", zorder=0)
    low = test["auroc"] - test["ci_low"]
    high = test["ci_high"] - test["auroc"]
    ax.errorbar(
        test["auroc"],
        0,
        xerr=[[low], [high]],
        fmt="o",
        markersize=7,
        color=ORANGE,
        ecolor=ORANGE,
        elinewidth=2.0,
        capsize=4,
        capthick=1.1,
        zorder=3,
    )
    ax.set_yticks([0], ["14B probe"])
    ax.set_ylim(-0.8, 0.8)
    ax.set_title("(b) Frozen test · 17 sources", loc="left", fontweight="bold")
    ax.text(test["auroc"], -0.30, "0.529  [0.498, 0.588]", ha="center", fontsize=7.8, color=DARK)
    ax.annotate(
        "95% CI includes chance",
        xy=(0.501, 0.02),
        xytext=(0.575, 0.48),
        ha="center",
        fontsize=7.8,
        color="#D55E00",
        fontweight="bold",
        arrowprops=dict(arrowstyle="->", color="#D55E00", linewidth=0.9),
    )

    for ax in axes:
        ax.set_xlim(0.45, 0.65)
        ax.set_xlabel("AUROC (unitless)")
        ax.grid(axis="x", color="#E5E7EB", linewidth=0.6, zorder=0)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    fig.subplots_adjust(left=0.17, right=0.985, top=0.86, bottom=0.24, wspace=0.43)
    fig.savefig("fig2_v2_selection.pdf", bbox_inches="tight", pad_inches=0.02)


if __name__ == "__main__":
    main()
